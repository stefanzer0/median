#pragma once
#include <cstdlib>

class Node
{
public:
	Node();
	int data;
	Node* next;
};