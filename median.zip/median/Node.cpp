#include "Node.h"

Node::Node() : data(0), next(NULL) {};